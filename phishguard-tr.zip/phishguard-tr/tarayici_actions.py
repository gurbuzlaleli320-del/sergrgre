#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🛡️ Türkçe Phishing Tarayıcı — GitHub Actions Versiyonu
certstream + crt.sh + PhishTank + URLhaus

6 saat boyunca tarar, tespitler.json ve tespitler.csv'ye kaydeder.
"""

import re, json, time, threading, hashlib, csv, os, sys
from datetime import datetime
from urllib.parse import urlparse
from collections import deque, defaultdict

try:
    import certstream
    CERTSTREAM_OK = True
except ImportError:
    CERTSTREAM_OK = False

try:
    import requests
    requests.packages.urllib3.disable_warnings()
except ImportError:
    print("[HATA] requests yüklü değil"); sys.exit(1)

# ── SÜRE AYARI ────────────────────────────────────────────────────────────────
TARAMA_SURE = int(os.environ.get("TARAMA_SURE", "21600"))  # 6 saat default
BITIS_ZAMANI = time.time() + TARAMA_SURE

# ── HEDEF MARKALAR ────────────────────────────────────────────────────────────
HEDEF_MARKALAR = [
    "garanti","garantibbva","isbank","ziraat","akbank","vakifbank",
    "halkbank","ykb","yapikredi","finansbank","qnb","denizbank",
    "teb","ing","hsbc","enpara","papara","param",
    "turkcell","vodafone","turktelekom","superonline","ttnet",
    "trendyol","hepsiburada","gittigidiyor","ciceksepeti","n11",
    "ptt","mhrs","turkiye","egov","edevlet","sgk","gib","nvi",
    "btcturk","paribu","binance",
    "gmail","outlook","apple","microsoft",
]

WHITELIST = {
    "garanti.com","garantibbva.com","isbank.com.tr","ziraatbank.com.tr",
    "akbank.com","vakifbank.com.tr","halkbank.com.tr","yapikredi.com.tr",
    "qnbfinansbank.com","denizbank.com","teb.com.tr","enpara.com","papara.com",
    "turkcell.com.tr","vodafone.com.tr","turktelekom.com.tr",
    "trendyol.com","hepsiburada.com","n11.com","ptt.gov.tr",
    "btcturk.com","paribu.com","binance.com","google.com",
    "gmail.com","outlook.com","microsoft.com","apple.com",
}

TURKCE_KARAKTERLER = set("çğıöşüÇĞİÖŞÜ")

RISKLI_TLD = {
    ".tk",".ml",".ga",".cf",".gq",
    ".xyz",".top",".click",".link",
    ".online",".site",".website",".tech",
    ".icu",".fun",".space",".live",".pw",
    ".cc",".ws",".biz",".uno",
}

PHISHING_RE = re.compile(
    r"(giris|giri[sş]|login|secure|verify|dogrula|do[gğ]rula|"
    r"hesap|account|banking|banka|update|g[uü]venlik|security|"
    r"confirm|onay|sifre|[sş]ifre|password|parola|activate|"
    r"musteri|m[uü][sş]teri|destek|odeme|[oö]deme|yenile|"
    r"renew|expire|uyar[ıi]|alert|bildirim)",
    re.IGNORECASE
)

# ── VERİ DEPOSU ───────────────────────────────────────────────────────────────
tespitler  = deque(maxlen=5000)
istatistik = defaultdict(int)
goruldu    = set()
lock       = threading.Lock()
baslangic  = datetime.now()

# ── SKOR MOTORU ───────────────────────────────────────────────────────────────
def skor_hesapla(domain: str):
    skor = 0
    sebepler = []
    hedef = None
    d = domain.lower().strip("*.").rstrip(".")

    for w in WHITELIST:
        if d == w or d == "www." + w:
            return 0, [], None

    for marka in HEDEF_MARKALAR:
        if marka in d:
            is_real = any(d == w or d.endswith("."+w) for w in WHITELIST if marka in w)
            if not is_real:
                skor += 40
                sebepler.append(f"Marka taklidi [{marka}]")
                hedef = marka
            break

    if any(c in TURKCE_KARAKTERLER for c in domain):
        skor += 25
        sebepler.append("IDN/Türkçe karakter")

    for tld in RISKLI_TLD:
        if d.endswith(tld):
            skor += 20
            sebepler.append(f"Riskli TLD [{tld}]")
            break

    m = PHISHING_RE.search(d)
    if m:
        skor += 15
        sebepler.append(f"Phishing kelimesi [{m.group()}]")

    tire = d.count("-")
    if tire >= 4:   skor += 12; sebepler.append(f"Çok tire [{tire}x]")
    elif tire >= 2: skor += 5

    if len(d) > 45:
        skor += 8
        sebepler.append(f"Uzun domain [{len(d)}kr]")

    return min(skor, 100), sebepler, hedef


def seviye(skor):
    if skor >= 75: return "YÜKSEK"
    if skor >= 45: return "ORTA"
    if skor >= 20: return "DÜŞÜK"
    return "TEMİZ"


# ── ÇIKTI & KAYIT ─────────────────────────────────────────────────────────────
def isle(domain: str, kaynak: str):
    if not domain or len(domain) < 5:
        return
    if time.time() > BITIS_ZAMANI:
        return  # Süre doldu

    h = hashlib.md5(domain.encode()).hexdigest()
    with lock:
        if h in goruldu:
            return
        goruldu.add(h)
        istatistik["taranan"] += 1

    skor, sebepler, hedef = skor_hesapla(domain)
    if skor < 20:
        return

    sv = seviye(skor)
    with lock:
        if skor >= 45: istatistik["aday"] += 1
        if skor >= 75: istatistik["yuksek"] += 1

    t = {
        "id":       h[:8],
        "domain":   domain,
        "skor":     skor,
        "seviye":   sv,
        "sebepler": sebepler,
        "hedef":    hedef or "",
        "kaynak":   kaynak,
        "zaman":    datetime.now().strftime("%H:%M:%S"),
        "tarih":    datetime.now().strftime("%Y-%m-%d"),
    }

    with lock:
        tespitler.appendleft(t)

    # Terminale yaz
    emoji = {"YÜKSEK": "🔴", "ORTA": "🟠", "DÜŞÜK": "🟡"}.get(sv, "🟢")
    print(f"{t['zaman']}  {emoji} {sv:7}  {domain[:60]:60}  {skor:3}/100  [{kaynak}]")
    if sebepler:
        print(f"          ↳ {' · '.join(sebepler)}")

    # Dosyaya kaydet
    if len(tespitler) % 10 == 0:
        _kaydet()


def _kaydet():
    """JSON ve CSV'ye yaz."""
    gecen = (datetime.now() - baslangic).seconds
    kalan = max(0, TARAMA_SURE - gecen)

    with open("tespitler.json", "w", encoding="utf-8") as f:
        json.dump({
            "meta": {
                "baslangic":   baslangic.isoformat(),
                "taranan":     istatistik["taranan"],
                "aday":        istatistik["aday"],
                "yuksek_risk": istatistik["yuksek"],
                "gecen_sure":  gecen,
                "kalan_sure":  kalan,
            },
            "tespitler": list(tespitler)
        }, f, ensure_ascii=False, indent=2)

    csv_yeni = not os.path.exists("tespitler.csv")
    with open("tespitler.csv", "a", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["tarih","zaman","domain","skor","seviye","hedef","sebepler","kaynak"])
        if csv_yeni:
            w.writeheader()
        for t in list(tespitler)[:10]:
            w.writerow({**t, "sebepler": " | ".join(t.get("sebepler", []))})


# ══════════════════════════════════════════════════════════════════════════════
# KAYNAK 1: certstream
# ══════════════════════════════════════════════════════════════════════════════
def certstream_baslat():
    if not CERTSTREAM_OK:
        print("[certstream] Yüklü değil, atlanıyor.")
        return

    print("[certstream] Bağlanıyor...")

    def callback(msg, ctx):
        if time.time() > BITIS_ZAMANI:
            sys.exit(0)
        if msg.get("message_type") != "certificate_update":
            return
        domains = msg.get("data", {}).get("leaf_cert", {}).get("all_domains", [])
        for d in domains:
            isle(d, "certstream")

    def on_error(e, ctx):
        print(f"[certstream] Hata: {e} — yeniden bağlanıyor...")
        time.sleep(5)

    try:
        certstream.listen_for_events(callback, on_error=on_error,
                                     url="wss://certstream.calidog.io")
    except Exception as e:
        print(f"[certstream] Başlatılamadı: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# KAYNAK 2: crt.sh
# ══════════════════════════════════════════════════════════════════════════════
def crtsh_dongu():
    print("[crt.sh] Tarama başladı...")
    while time.time() < BITIS_ZAMANI:
        for marka in HEDEF_MARKALAR:
            if time.time() > BITIS_ZAMANI:
                break
            try:
                r = requests.get(
                    f"https://crt.sh/?q=%25{marka}%25&output=json",
                    timeout=20, verify=False
                )
                if r.status_code == 200:
                    for cert in r.json()[:50]:
                        for d in cert.get("name_value", "").split("\n"):
                            isle(d.strip(), "crt.sh")
            except Exception:
                pass
            time.sleep(2)

        print(f"[crt.sh] Döngü tamamlandı — 30dk bekleniyor")
        time.sleep(1800)


# ══════════════════════════════════════════════════════════════════════════════
# KAYNAK 3: PhishTank
# ══════════════════════════════════════════════════════════════════════════════
def phishtank_dongu():
    print("[PhishTank] Çekim başladı...")
    while time.time() < BITIS_ZAMANI:
        try:
            r = requests.get(
                "http://data.phishtank.com/data/online-valid.json",
                timeout=60
            )
            print(f"[PhishTank] {len(r.json())} kayıt alındı")
            for item in r.json():
                if time.time() > BITIS_ZAMANI:
                    break
                url = item.get("url", "")
                domain = urlparse(url).netloc
                if domain:
                    isle(domain, "phishtank")
        except Exception as e:
            print(f"[PhishTank] Hata: {e}")

        time.sleep(3600)  # 1 saat


# ══════════════════════════════════════════════════════════════════════════════
# KAYNAK 4: URLhaus
# ══════════════════════════════════════════════════════════════════════════════
def urlhaus_dongu():
    print("[URLhaus] Çekim başladı...")
    while time.time() < BITIS_ZAMANI:
        try:
            r = requests.get(
                "https://urlhaus.abuse.ch/downloads/csv_recent/",
                timeout=30, verify=False
            )
            count = 0
            for satir in r.text.split("\n"):
                if satir.startswith("#") or not satir.strip():
                    continue
                parcalar = satir.split(",")
                if len(parcalar) >= 3:
                    try:
                        domain = urlparse(parcalar[2].strip().strip('"')).netloc
                        if domain:
                            isle(domain, "urlhaus")
                            count += 1
                    except Exception:
                        pass
            print(f"[URLhaus] {count} URL işlendi")
        except Exception as e:
            print(f"[URLhaus] Hata: {e}")

        time.sleep(900)  # 15 dakika


# ══════════════════════════════════════════════════════════════════════════════
# ANA PROGRAM
# ══════════════════════════════════════════════════════════════════════════════
def main():
    sure_saat = TARAMA_SURE // 3600
    print(f"""
╔══════════════════════════════════════════════════════════════════╗
║      🛡️  TÜRKÇE PHİSHİNG TARAYICI — GitHub Actions              ║
║      Süre: {sure_saat} saat  |  Başlangıç: {baslangic.strftime('%H:%M:%S')}               ║
╚══════════════════════════════════════════════════════════════════╝
""")

    threadler = []

    for fn, isim in [
        (crtsh_dongu,     "crt.sh"),
        (phishtank_dongu, "PhishTank"),
        (urlhaus_dongu,   "URLhaus"),
    ]:
        t = threading.Thread(target=fn, daemon=True, name=isim)
        t.start()
        threadler.append(t)
        time.sleep(3)

    # certstream ana thread'de
    if CERTSTREAM_OK:
        certstream_baslat()
    else:
        # certstream yoksa süre dolana kadar bekle
        while time.time() < BITIS_ZAMANI:
            time.sleep(60)
            gecen = int((time.time() - baslangic.timestamp()) / 60)
            print(f"[{datetime.now().strftime('%H:%M:%S')}] {gecen}dk geçti | "
                  f"Taranan: {istatistik['taranan']:,} | "
                  f"Aday: {istatistik['aday']:,} | "
                  f"Yüksek: {istatistik['yuksek']:,}")

    # Bitti — son kayıt
    _kaydet()
    print(f"""
╔══════════════════════════════════════════════════════════════════╗
║  ✅ TARAMA TAMAMLANDI
║  Taranan     : {istatistik['taranan']:,}
║  Phishing aday: {istatistik['aday']:,}
║  Yüksek risk : {istatistik['yuksek']:,}
║  Dosyalar    : tespitler.json + tespitler.csv
╚══════════════════════════════════════════════════════════════════╝
""")


if __name__ == "__main__":
    main()
