# 🛡️ PhishGuard TR — Türkçe Phishing Tarayıcı

## Kurulum
1. Bu repo'yu GitHub'a yükleyin
2. Actions sekmesine gidin → Enable workflows
3. "Türkçe Phishing Tarayıcı" → Run workflow

## Kaynaklar
- certstream (anlık SSL)
- crt.sh (marka tarama)
- PhishTank (doğrulanmış DB)
- URLhaus (kötü amaçlı URL)

## Sonuçlar
Her çalışma sonrası Actions → Artifacts → tespitler.zip
